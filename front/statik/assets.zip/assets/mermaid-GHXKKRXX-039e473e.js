import{p as t}from"./index-d9dc20f9.js";import"./vendor-ff04f3e1.js";import"./antdChunk-22ee0fd7.js";import"./vendor1-1bba1bae.js";export{t as Mermaid};
