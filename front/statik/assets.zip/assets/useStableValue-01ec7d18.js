import{r as e,aZ as s}from"./vendor-de462557.js";function n(r){const t=e.useRef(r);return s(t.current,r)||(t.current=r),t.current}export{n as u};
