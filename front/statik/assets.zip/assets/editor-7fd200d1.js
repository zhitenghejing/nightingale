import{A as R,j as S}from"./index-8ff659ab.js";import{r as B}from"./vendor-607bd3a1.js";import{_ as w}from"./vendor2-03c3643b.js";var M={exports:{}};(function(u,x){ace.define("ace/mode/sh_highlight_rules",["require","exports","module","ace/lib/oop","ace/mode/text_highlight_rules"],function(n,l,m){var h=n("../lib/oop"),A=n("./text_highlight_rules").TextHighlightRules,v=l.reservedKeywords="!|{|}|case|do|done|elif|else|esac|fi|for|if|in|then|until|while|&|;|export|local|read|typeset|unset|elif|select|set|function|declare|readonly",f=l.languageConstructs="[|]|alias|bg|bind|break|builtin|cd|command|compgen|complete|continue|dirs|disown|echo|enable|eval|exec|exit|fc|fg|getopts|hash|help|history|jobs|kill|let|logout|popd|printf|pushd|pwd|return|set|shift|shopt|source|suspend|test|times|trap|type|ulimit|umask|unalias|wait",a=function(){var r=this.createKeywordMapper({keyword:v,"support.function.builtin":f,"invalid.deprecated":"debugger"},"identifier"),o="(?:(?:[1-9]\\d*)|(?:0))",s="(?:\\.\\d+)",t="(?:\\d+)",i="(?:(?:"+t+"?"+s+")|(?:"+t+"\\.))",c="(?:(?:"+i+"|"+t+"))",e="(?:"+c+"|"+i+")",g="(?:&"+t+")",d="[a-zA-Z_][a-zA-Z0-9_]*",y="(?:"+d+"(?==))",F="(?:\\$(?:SHLVL|\\$|\\!|\\?))",E="(?:"+d+"\\s*\\(\\))";this.$rules={start:[{token:"constant",regex:/\\./},{token:["text","comment"],regex:/(^|\s)(#.*)$/},{token:"string.start",regex:'"',push:[{token:"constant.language.escape",regex:/\\(?:[$`"\\]|$)/},{include:"variables"},{token:"keyword.operator",regex:/`/},{token:"string.end",regex:'"',next:"pop"},{defaultToken:"string"}]},{token:"string",regex:"\\$'",push:[{token:"constant.language.escape",regex:/\\(?:[abeEfnrtv\\'"]|x[a-fA-F\d]{1,2}|u[a-fA-F\d]{4}([a-fA-F\d]{4})?|c.|\d{1,3})/},{token:"string",regex:"'",next:"pop"},{defaultToken:"string"}]},{regex:"<<<",token:"keyword.operator"},{stateName:"heredoc",regex:"(<<-?)(\\s*)(['\"`]?)([\\w\\-]+)(['\"`]?)",onMatch:function(p,_,k){var C=p[2]=="-"?"indentedHeredoc":"heredoc",b=p.split(this.splitRegex);return k.push(C,b[4]),[{type:"constant",value:b[1]},{type:"text",value:b[2]},{type:"string",value:b[3]},{type:"support.class",value:b[4]},{type:"string",value:b[5]}]},rules:{heredoc:[{onMatch:function(p,_,k){return p===k[1]?(k.shift(),k.shift(),this.next=k[0]||"start","support.class"):(this.next="","string")},regex:".*$",next:"start"}],indentedHeredoc:[{token:"string",regex:"^	+"},{onMatch:function(p,_,k){return p===k[1]?(k.shift(),k.shift(),this.next=k[0]||"start","support.class"):(this.next="","string")},regex:".*$",next:"start"}]}},{regex:"$",token:"empty",next:function(p,_){return _[0]==="heredoc"||_[0]==="indentedHeredoc"?_[0]:p}},{token:["keyword","text","text","text","variable"],regex:/(declare|local|readonly)(\s+)(?:(-[fixar]+)(\s+))?([a-zA-Z_][a-zA-Z0-9_]*\b)/},{token:"variable.language",regex:F},{token:"variable",regex:y},{include:"variables"},{token:"support.function",regex:E},{token:"support.function",regex:g},{token:"string",start:"'",end:"'"},{token:"constant.numeric",regex:e},{token:"constant.numeric",regex:o+"\\b"},{token:r,regex:"[a-zA-Z_][a-zA-Z0-9_]*\\b"},{token:"keyword.operator",regex:"\\+|\\-|\\*|\\*\\*|\\/|\\/\\/|~|<|>|<=|=>|=|!=|[%&|`]"},{token:"punctuation.operator",regex:";"},{token:"paren.lparen",regex:"[\\[\\(\\{]"},{token:"paren.rparen",regex:"[\\]]"},{token:"paren.rparen",regex:"[\\)\\}]",next:"pop"}],variables:[{token:"variable",regex:/(\$)(\w+)/},{token:["variable","paren.lparen"],regex:/(\$)(\()/,push:"start"},{token:["variable","paren.lparen","keyword.operator","variable","keyword.operator"],regex:/(\$)(\{)([#!]?)(\w+|[*@#?\-$!0_])(:[?+\-=]?|##?|%%?|,,?\/|\^\^?)?/,push:"start"},{token:"variable",regex:/\$[*@#?\-$!0_]/},{token:["variable","paren.lparen"],regex:/(\$)(\{)/,push:"start"}]},this.normalizeRules()};h.inherits(a,A),l.ShHighlightRules=a}),ace.define("ace/mode/folding/cstyle",["require","exports","module","ace/lib/oop","ace/range","ace/mode/folding/fold_mode"],function(n,l,m){var h=n("../../lib/oop"),A=n("../../range").Range,v=n("./fold_mode").FoldMode,f=l.FoldMode=function(a){a&&(this.foldingStartMarker=new RegExp(this.foldingStartMarker.source.replace(/\|[^|]*?$/,"|"+a.start)),this.foldingStopMarker=new RegExp(this.foldingStopMarker.source.replace(/\|[^|]*?$/,"|"+a.end)))};h.inherits(f,v),function(){this.foldingStartMarker=/([\{\[\(])[^\}\]\)]*$|^\s*(\/\*)/,this.foldingStopMarker=/^[^\[\{\(]*([\}\]\)])|^[\s\*]*(\*\/)/,this.singleLineBlockCommentRe=/^\s*(\/\*).*\*\/\s*$/,this.tripleStarBlockCommentRe=/^\s*(\/\*\*\*).*\*\/\s*$/,this.startRegionRe=/^\s*(\/\*|\/\/)#?region\b/,this._getFoldWidgetBase=this.getFoldWidget,this.getFoldWidget=function(a,r,o){var s=a.getLine(o);if(this.singleLineBlockCommentRe.test(s)&&!this.startRegionRe.test(s)&&!this.tripleStarBlockCommentRe.test(s))return"";var t=this._getFoldWidgetBase(a,r,o);return!t&&this.startRegionRe.test(s)?"start":t},this.getFoldWidgetRange=function(a,r,o,s){var t=a.getLine(o);if(this.startRegionRe.test(t))return this.getCommentRegionBlock(a,t,o);var e=t.match(this.foldingStartMarker);if(e){var i=e.index;if(e[1])return this.openingBracketBlock(a,e[1],o,i);var c=a.getCommentFoldRange(o,i+e[0].length,1);return c&&!c.isMultiLine()&&(s?c=this.getSectionRange(a,o):r!="all"&&(c=null)),c}if(r!=="markbegin"){var e=t.match(this.foldingStopMarker);if(e){var i=e.index+e[0].length;return e[1]?this.closingBracketBlock(a,e[1],o,i):a.getCommentFoldRange(o,i,-1)}}},this.getSectionRange=function(a,r){var o=a.getLine(r),s=o.search(/\S/),t=r,i=o.length;r=r+1;for(var c=r,e=a.getLength();++r<e;){o=a.getLine(r);var g=o.search(/\S/);if(g!==-1){if(s>g)break;var d=this.getFoldWidgetRange(a,"all",r);if(d){if(d.start.row<=t)break;if(d.isMultiLine())r=d.end.row;else if(s==g)break}c=r}}return new A(t,i,c,a.getLine(c).length)},this.getCommentRegionBlock=function(a,r,o){for(var s=r.search(/\s*$/),t=a.getLength(),i=o,c=/^\s*(?:\/\*|\/\/|--)#?(end)?region\b/,e=1;++o<t;){r=a.getLine(o);var g=c.exec(r);if(g&&(g[1]?e--:e++,!e))break}var d=o;if(d>i)return new A(i,s,d,r.length)}}.call(f.prototype)}),ace.define("ace/mode/sh",["require","exports","module","ace/lib/oop","ace/mode/text","ace/mode/sh_highlight_rules","ace/range","ace/mode/folding/cstyle"],function(n,l,m){var h=n("../lib/oop"),A=n("./text").Mode,v=n("./sh_highlight_rules").ShHighlightRules,f=n("../range").Range,a=n("./folding/cstyle").FoldMode,r=function(){this.HighlightRules=v,this.foldingRules=new a,this.$behaviour=this.$defaultBehaviour};h.inherits(r,A),function(){this.lineCommentStart="#",this.getNextLineIndent=function(s,t,i){var c=this.$getIndent(t),e=this.getTokenizer().getLineTokens(t,s),g=e.tokens;if(g.length&&g[g.length-1].type=="comment")return c;if(s=="start"){var d=t.match(/^.*[\{\(\[:]\s*$/);d&&(c+=i)}return c};var o={pass:1,return:1,raise:1,break:1,continue:1};this.checkOutdent=function(s,t,i){if(i!==`\r
`&&i!=="\r"&&i!==`
`)return!1;var c=this.getTokenizer().getLineTokens(t.trim(),s).tokens;if(!c)return!1;do var e=c.pop();while(e&&(e.type=="comment"||e.type=="text"&&e.value.match(/^\s+$/)));return e?e.type=="keyword"&&o[e.value]:!1},this.autoOutdent=function(s,t,i){i+=1;var c=this.$getIndent(t.getLine(i)),e=t.getTabString();c.slice(-e.length)==e&&t.remove(new f(i,c.length-e.length,i,c.length))},this.$id="ace/mode/sh",this.snippetFileId="ace/snippets/sh"}.call(r.prototype),l.Mode=r}),function(){ace.require(["ace/mode/sh"],function(n){u&&(u.exports=n)})}()})(M);var $={exports:{}};(function(u,x){ace.define("ace/theme/monokai-css",["require","exports","module"],function(n,l,m){m.exports=`.ace-monokai .ace_gutter {
  background: #2F3129;
  color: #8F908A
}

.ace-monokai .ace_print-margin {
  width: 1px;
  background: #555651
}

.ace-monokai {
  background-color: #272822;
  color: #F8F8F2
}

.ace-monokai .ace_cursor {
  color: #F8F8F0
}

.ace-monokai .ace_marker-layer .ace_selection {
  background: #49483E
}

.ace-monokai.ace_multiselect .ace_selection.ace_start {
  box-shadow: 0 0 3px 0px #272822;
}

.ace-monokai .ace_marker-layer .ace_step {
  background: rgb(102, 82, 0)
}

.ace-monokai .ace_marker-layer .ace_bracket {
  margin: -1px 0 0 -1px;
  border: 1px solid #49483E
}

.ace-monokai .ace_marker-layer .ace_active-line {
  background: #202020
}

.ace-monokai .ace_gutter-active-line {
  background-color: #272727
}

.ace-monokai .ace_marker-layer .ace_selected-word {
  border: 1px solid #49483E
}

.ace-monokai .ace_invisible {
  color: #52524d
}

.ace-monokai .ace_entity.ace_name.ace_tag,
.ace-monokai .ace_keyword,
.ace-monokai .ace_meta.ace_tag,
.ace-monokai .ace_storage {
  color: #F92672
}

.ace-monokai .ace_punctuation,
.ace-monokai .ace_punctuation.ace_tag {
  color: #fff
}

.ace-monokai .ace_constant.ace_character,
.ace-monokai .ace_constant.ace_language,
.ace-monokai .ace_constant.ace_numeric,
.ace-monokai .ace_constant.ace_other {
  color: #AE81FF
}

.ace-monokai .ace_invalid {
  color: #F8F8F0;
  background-color: #F92672
}

.ace-monokai .ace_invalid.ace_deprecated {
  color: #F8F8F0;
  background-color: #AE81FF
}

.ace-monokai .ace_support.ace_constant,
.ace-monokai .ace_support.ace_function {
  color: #66D9EF
}

.ace-monokai .ace_fold {
  background-color: #A6E22E;
  border-color: #F8F8F2
}

.ace-monokai .ace_storage.ace_type,
.ace-monokai .ace_support.ace_class,
.ace-monokai .ace_support.ace_type {
  font-style: italic;
  color: #66D9EF
}

.ace-monokai .ace_entity.ace_name.ace_function,
.ace-monokai .ace_entity.ace_other,
.ace-monokai .ace_entity.ace_other.ace_attribute-name,
.ace-monokai .ace_variable {
  color: #A6E22E
}

.ace-monokai .ace_variable.ace_parameter {
  font-style: italic;
  color: #FD971F
}

.ace-monokai .ace_string {
  color: #E6DB74
}

.ace-monokai .ace_comment {
  color: #75715E
}

.ace-monokai .ace_indent-guide {
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAEklEQVQImWPQ0FD0ZXBzd/wPAAjVAoxeSgNeAAAAAElFTkSuQmCC) right repeat-y
}

.ace-monokai .ace_indent-guide-active {
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAEklEQVQIW2PQ1dX9zzBz5sz/ABCcBFFentLlAAAAAElFTkSuQmCC) right repeat-y;
}
`}),ace.define("ace/theme/monokai",["require","exports","module","ace/theme/monokai-css","ace/lib/dom"],function(n,l,m){l.isDark=!0,l.cssClass="ace-monokai",l.cssText=n("./monokai-css");var h=n("../lib/dom");h.importCssString(l.cssText,l.cssClass,!1)}),function(){ace.require(["ace/theme/monokai"],function(n){u&&(u.exports=n)})}()})($);var L={exports:{}};(function(u,x){ace.define("ace/theme/kuroir-css",["require","exports","module"],function(n,l,m){m.exports=`/* THIS THEME WAS AUTOGENERATED BY Theme.tmpl.css (UUID: 467560D0-6ACE-4409-82FD-4791420837AC) */

.ace-kuroir .ace_gutter {
  background: #e8e8e8;
  color: #333;
}

.ace-kuroir .ace_print-margin {
  width: 1px;
  background: #e8e8e8;
}

.ace-kuroir {
  background-color: #E8E9E8;
  color: #363636;
}

.ace-kuroir .ace_cursor {
  color: #202020;
}

.ace-kuroir .ace_marker-layer .ace_selection {
  background: rgba(245, 170, 0, 0.57);
}

.ace-kuroir.ace_multiselect .ace_selection.ace_start {
  box-shadow: 0 0 3px 0px #E8E9E8;
}

.ace-kuroir .ace_marker-layer .ace_step {
  background: rgb(198, 219, 174);
}

.ace-kuroir .ace_marker-layer .ace_bracket {
  margin: -1px 0 0 -1px;
  border: 1px solid rgba(0, 0, 0, 0.29);
}

.ace-kuroir .ace_marker-layer .ace_active-line {
  background: rgba(203, 220, 47, 0.22);
}

.ace-kuroir .ace_gutter-active-line {
  background-color: rgba(203, 220, 47, 0.22);
}

.ace-kuroir .ace_marker-layer .ace_selected-word {
  border: 1px solid rgba(245, 170, 0, 0.57);
}

.ace-kuroir .ace_invisible {
  color: #BFBFBF
}

.ace-kuroir .ace_fold {
  border-color: #363636;
}





.ace-kuroir .ace_constant{color:#CD6839;}.ace-kuroir .ace_constant.ace_numeric{color:#9A5925;}.ace-kuroir .ace_support{color:#104E8B;}.ace-kuroir .ace_support.ace_function{color:#005273;}.ace-kuroir .ace_support.ace_constant{color:#CF6A4C;}.ace-kuroir .ace_storage{color:#A52A2A;}.ace-kuroir .ace_invalid.ace_illegal{color:#FD1224;
background-color:rgba(255, 6, 0, 0.15);}.ace-kuroir .ace_invalid.ace_deprecated{text-decoration:underline;
font-style:italic;
color:#FD1732;
background-color:#E8E9E8;}.ace-kuroir .ace_string{color:#639300;}.ace-kuroir .ace_string.ace_regexp{color:#417E00;
background-color:#C9D4BE;}.ace-kuroir .ace_comment{color:rgba(148, 148, 148, 0.91);
background-color:rgba(220, 220, 220, 0.56);}.ace-kuroir .ace_variable{color:#009ACD;}.ace-kuroir .ace_meta.ace_tag{color:#005273;}.ace-kuroir .ace_markup.ace_heading{color:#B8012D;
background-color:rgba(191, 97, 51, 0.051);}.ace-kuroir .ace_markup.ace_list{color:#8F5B26;}

.ace-kuroir .ace_indent-guide {
    background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAE0lEQVQImWP4////f4bLly//BwAmVgd1/w11/gAAAABJRU5ErkJggg==") right repeat-y;
}

.ace-kuroir .ace_indent-guide-active {
  background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAZSURBVHjaYvj///9/hivKyv8BAAAA//8DACLqBhbvk+/eAAAAAElFTkSuQmCC") right repeat-y;
} 
`}),ace.define("ace/theme/kuroir",["require","exports","module","ace/theme/kuroir-css","ace/lib/dom"],function(n,l,m){l.isDark=!1,l.cssClass="ace-kuroir",l.cssText=n("./kuroir-css");var h=n("../lib/dom");h.importCssString(l.cssText,l.cssClass,!1)}),function(){ace.require(["ace/theme/kuroir"],function(n){u&&(u.exports=n)})}()})(L);function T(u){const{darkMode:x}=B.useContext(R);return S.jsx(w,{placeholder:"Placeholder Text",style:{width:"100%"},height:u.height,mode:"sh",theme:x?"monokai":"kuroir",name:"blah2",fontSize:14,showPrintMargin:!1,showGutter:!0,readOnly:u.readOnly,highlightActiveLine:!0,setOptions:{enableBasicAutocompletion:!0,enableLiveAutocompletion:!0,enableSnippets:!0,showLineNumbers:!0,tabSize:2},value:u.value,onChange:n=>{u.onChange&&u.onChange(n)}})}T.defaultProps={readOnly:!1,height:"500px"};export{T as E};
