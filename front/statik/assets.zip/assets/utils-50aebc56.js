import"./vendor-76b3c452.js";const o=(r,n)=>!r||n==="second"?r:n==="min"?r*60:n==="hour"?r*60*60:n==="day"?r*60*60*24:r;export{o as n};
