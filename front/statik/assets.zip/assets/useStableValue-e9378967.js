import{r as e,aZ as s}from"./vendor-81424a2b.js";function n(r){const t=e.useRef(r);return s(t.current,r)||(t.current=r),t.current}export{n as u};
