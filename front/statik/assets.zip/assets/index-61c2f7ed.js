import{M as l,u,j as n,K as E,bK as s}from"./index-a2c1c483.js";import{aG as g}from"./vendor-515d5120.js";import{M as c}from"./index-cf777518.js";import{i as h}from"./antdChunk-ec24a389.js";const d=`#  MySQL文档说明

### 查询表格

和在终端登录 MySQL 之后，输入 SQL 查询类似，例如查询整个表的数据：
\`\`\`sql
select * from database_name.table_name limit 10
\`\`\`
### 查询时序图

1. 必须在 SQL 中使用 \`as time\` 的语法指定哪一列是时间列，然后 \`group by time order by time desc\` 对时间做排序，例如

\`\`\`sql
select count(*) as count, trigger_time as time 
from n9e_v6_plus.alert_his_event 
group by time 
order by time 
desc LIMIT 100
\`\`\`

2. 可以使用 where 条件，执行查询某一个时间段的数据，样例如下

> 2.1  查询最近一分钟的数据，也可以把 MINUTE 换成 SECOND、HOUR、DAY、WEEK、MONTH 等
\`\`\`sql
SELECT count(*) AS count, trigger_time AS time FROM n9e_v6_plus.alert_his_event  WHERE FROM_UNIXTIME(trigger_time) >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
\`\`\`
   
> 2.2 查询某一个时间段的数据，trigger_time 是 unix 时间戳 (1720061167) 的情况   
WHERE 语句可以直接写 WHERE trigger_time >= 1720060214 AND trigger_time < 1720061214   
或者 trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo(), $__unixEpochFrom() 表示开始的unix时间戳，$__unixEpochTo() 表示结束时间的unix时间戳

\`\`\`sql
SELECT count(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event  
WHERE trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo()
GROUP BY time 
ORDER BY time DESC
\`\`\`

> 2.3 查询某一个时间段的数据，trigger_time 是 2024-07-04 10:48:01 字符串格式的情况   
WHERE 语句可以直接写 WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"
\`\`\`sql
SELECT count(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event  
WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"
GROUP BY time 
ORDER BY time DESC
\`\`\`
   
> 2.4 查询最近 7 天每分钟产生的告警数量
\`\`\`sql
SELECT FROM_UNIXTIME(trigger_time, '%Y-%m-%d %H:%i:00') AS alert_minute,COUNT(*) AS alert_count 
FROM n9e_v6_plus.alert_his_event 
WHERE trigger_time >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY)) 
GROUP BY alert_minute 
ORDER BY alert_minute DESC;
\`\`\`
   
> 2.5 alert_his_event 样例表结构如下
\`\`\`sql
CREATE TABLE \`alert_his_event\` (
    \`id\` bigint unsigned not null AUTO_INCREMENT,
    \`cate\` varchar(128) not null,
    \`rule_id\` bigint unsigned not null,
    \`rule_name\` varchar(255) not null,
    \`prom_ql\` varchar(8192) not null comment 'promql',
    \`first_trigger_time\` bigint,
    \`trigger_time\` bigint not null,
    \`trigger_value\` varchar(255) not null,
    PRIMARY KEY (\`id\`),
    KEY (\`trigger_time\`, \`rule_id\`)
) ENGINE=InnoDB DEFAULT CHARSET = utf8mb4;
\`\`\`

### 宏变量使用

在配置仪表盘的时候，一般我们要查询数据的时间范围不是固定的，需要随着仪表盘右上角的时间返回变化而变化，这个时候就需要使用和时间相关的宏变量了，下面是我们目前支持的宏变量以及使用说明
（备注：下面说明中的 1494410783 是前端传的 start_time，1494410983 是前端传的 end_time）

|  **宏变量**  |  **描述**  |
| --- | --- |
|  \`$__timeFilter(dateColumn)\`  |  如果 \`dateColumn\` 格式是 \`%Y-%m-%d %H:%i:%s\`，可以使用此宏变量，将被替换为  _dateColumn BETWEEN FROM\\_UNIXTIME(1494410783) AND FROM\\_UNIXTIME(1494410983)_  |
|  \`$__timeFrom()\`  |  如果时间列格式是\`%Y-%m-%d %H:%i:%s\`，可以使用此宏变量，将被替换为当前时间选择的开始时间。_FROM\\_UNIXTIME(1494410783)_  |
|  \`$__timeTo()\`  |  如果时间列格式是\`%Y-%m-%d %H:%i:%s\`，可以使用此宏变量，将被替换为当前时间选择的结束时间。_FROM\\_UNIXTIME(1494410983)_  |
|  \`$__unixEpochFilter(dateColumn)\`  |  如果 \`dateColumn\` 格式是 Unix时间戳。将会被替换为 _dateColumn > 1494410783 AND dateColumn < 1494497183_  |
|  \`$__unixEpochFrom()\`  |  将被替换为当前活动时间选择的开始时间,以Unix时间戳表示。例如,_1494410783_  |
|  \`$__unixEpochTo()\`  |  将被替换为当前活动时间选择的结束时间, 以Unix时间戳表示。例如,_1494497183_  |
|  \`$__unixEpochNanoFilter(dateColumn)\`  |  如果 \`dateColumn\` 格式是以纳秒时间戳表示。将会被替换为 _dateColumn > 1494410783152415214 AND dateColumn < 1494410983142514872_  |
|  \`$__unixEpochNanoFrom()\`  |  将被替换为当前活动时间选择的开始时间,以纳秒时间戳表示。例如,_1494410783152415214_  |
|  \`$__unixEpochNanoTo()\`  |  将被替换为当前活动时间选择的结束时间,以纳秒时间戳表示。例如,_1494410983142514872_  |
|  \`$__timeGroup(dateColumn,'5m')\`  |  在 group by 的时候使用，以 5m 为分组粒度，对数据进行计算  |
|  \`$__unixEpochGroup(dateColumn,'5m')\`  |  在 group by 的时候使用，以 5m 为分组粒度，对数据进行计算  |

#### 宏变量使用示例
以上面的 alert_his_event 表为例，查询一段时间范围内每分钟的告警数量的 SQL 如下

\`\`\`sql
SELECT 
  $__unixEpochGroup(trigger_time, '1m') AS time,
  COUNT(*) AS alert_count
FROM 
  n9e_v6_plus.alert_his_event
WHERE 
  $__unixEpochFilter(trigger_time)
GROUP BY 
  time
ORDER BY 
  time
\`\`\`
`,p=`# MySQL 文檔說明

### 查詢表格

和在終端登錄 MySQL 之後，輸入 SQL 查詢類似，例如查詢整個表的數據：

\`\`\`sql
select * from database_name.table_name limit 10
\`\`\`

### 查詢時序圖

1. 必須在 SQL 中使用 \`as time\` 的語法指定哪一列是時間列，然後 \`group by time order by time desc\` 對時間做排序，例如

\`\`\`sql
select count(*) as count, trigger_time as time
from n9e_v6_plus.alert_his_event
group by time
order by time
desc LIMIT 100
\`\`\`

2. 可以使用 where 條件，執行查詢某一個時間段的數據，樣例如下

> 2.1 查詢最近一分鐘的數據，也可以把 MINUTE 換成 SECOND、HOUR、DAY、WEEK、MONTH 等

\`\`\`sql
SELECT count(*) AS count, trigger_time AS time FROM n9e_v6_plus.alert_his_event  WHERE FROM_UNIXTIME(trigger_time) >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
\`\`\`

> 2.2 查詢某一個時間段的數據，trigger_time 是 unix 時間戳 (1720061167) 的情況
> WHERE 語句可以直接寫 WHERE trigger_time >= 1720060214 AND trigger_time < 1720061214
> 或者 trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo(), $__unixEpochFrom() 表示開始的 unix 時間戳，$\\_\\_unixEpochTo() 表示結束時間的 unix 時間戳

\`\`\`sql
SELECT count(*) AS count, trigger_time AS time
FROM n9e_v6_plus.alert_his_event
WHERE trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo()
GROUP BY time
ORDER BY time DESC
\`\`\`

> 2.3 查詢某一個時間段的數據，trigger_time 是 2024-07-04 10:48:01 字符串格式的情況
> WHERE 語句可以直接寫 WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"

\`\`\`sql
SELECT count(*) AS count, trigger_time AS time
FROM n9e_v6_plus.alert_his_event
WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"
GROUP BY time
ORDER BY time DESC
\`\`\`

> 2.4 查詢最近 7 天每分鐘產生的告警數量

\`\`\`sql
SELECT FROM_UNIXTIME(trigger_time, '%Y-%m-%d %H:%i:00') AS alert_minute,COUNT(*) AS alert_count
FROM n9e_v6_plus.alert_his_event
WHERE trigger_time >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY))
GROUP BY alert_minute
ORDER BY alert_minute DESC;
\`\`\`

> 2.5 alert_his_event 樣例表結構如下

\`\`\`sql
CREATE TABLE \`alert_his_event\` (
    \`id\` bigint unsigned not null AUTO_INCREMENT,
    \`cate\` varchar(128) not null,
    \`rule_id\` bigint unsigned not null,
    \`rule_name\` varchar(255) not null,
    \`prom_ql\` varchar(8192) not null comment 'promql',
    \`first_trigger_time\` bigint,
    \`trigger_time\` bigint not null,
    \`trigger_value\` varchar(255) not null,
    PRIMARY KEY (\`id\`),
    KEY (\`trigger_time\`, \`rule_id\`)
) ENGINE=InnoDB DEFAULT CHARSET = utf8mb4;
\`\`\`

### 宏變量使用

在配置儀表盤的時候，一般我們要查詢數據的時間範圍不是固定的，需要隨著儀表盤右上角的時間返回變化而變化，這個時候就需要使用和時間相關的宏變量了，下面是我們目前支持的宏變量以及使用說明 （備註：下面說明中的 1494410783 是前端傳的 start_time，1494410983 是前端傳的 end_time）

\`\`\`
宏變量描述
$__timeFilter(dateColumn)如果 dateColumn 格式是 %Y-%m-%d %H:%i:%s，可以使用此宏變量，將被替換為 dateColumn BETWEEN FROM_UNIXTIME(1494410783) AND FROM_UNIXTIME(1494410983)
$__timeFrom()如果時間列格式是%Y-%m-%d %H:%i:%s，可以使用此宏變量，將被替換為當前時間選擇的開始時間。FROM_UNIXTIME(1494410783)
$__timeTo()如果時間列格式是%Y-%m-%d %H:%i:%s，可以使用此宏變量，將被替換為當前時間選擇的結束時間。FROM_UNIXTIME(1494410983)
$__unixEpochFilter(dateColumn)如果 dateColumn 格式是 Unix時間戳。將會被替換為 dateColumn > 1494410783 AND dateColumn < 1494497183
$__unixEpochFrom()將被替換為當前活動時間選擇的開始時間，以Unix時間戳表示。例如，1494410783
$__unixEpochTo()將被替換為當前活動時間選擇的結束時間，以Unix時間戳表示。例如，1494497183
$__unixEpochNanoFilter(dateColumn)如果 dateColumn 格式是以納秒時間戳表示。將會被替換為 dateColumn > 1494410783152415214 AND dateColumn < 1494410983142514872
$__unixEpochNanoFrom()將被替換為當前活動時間選擇的開始時間，以納秒時間戳表示。例如，1494410783152415214
$__unixEpochNanoTo()將被替換為當前活動時間選擇的結束時間，以納秒時間戳表示。例如，1494410983142514872
$__timeGroup(dateColumn,'5m')在 group by 的時候使用，以 5m 為分組粒度，對數據進行計算
$__unixEpochGroup(dateColumn,'5m')在 group by 的時候使用，以 5m 為分組粒度，對數據進行計算
\`\`\`

#### 宏變量使用示例

以上面的 alert_his_event 表為例，查詢一段時間範圍內每分鐘的告警數量的 SQL 如下

\`\`\`sql
SELECT
  $__unixEpochGroup(trigger_time, '1m') AS time,
  COUNT(*) AS alert_count
FROM
  n9e_v6_plus.alert_his_event
WHERE
  $__unixEpochFilter(trigger_time)
GROUP BY
  time
ORDER BY
  time
\`\`\`
`,R=`# MySQL Documentation

### Querying Tables

Similar to logging into MySQL via terminal and entering SQL queries, for example, to query the entire table's data:

\`\`\`sql
SELECT * FROM database_name.table_name LIMIT 10
\`\`\`

### Querying Time Series Data

1. You must use the \`AS time\` syntax in SQL to specify which column is the time column, then use \`GROUP BY time ORDER BY time DESC\` to sort by time, for example:

\`\`\`sql
SELECT COUNT(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event 
GROUP BY time 
ORDER BY time 
DESC LIMIT 100
\`\`\`

2. You can use WHERE conditions to query data for a specific time period, examples as follows:

> 2.1 Query data from the last minute, you can also replace MINUTE with SECOND, HOUR, DAY, WEEK, MONTH, etc.

\`\`\`sql
SELECT COUNT(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event  
WHERE FROM_UNIXTIME(trigger_time) >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
\`\`\`

> 2.2 Query data for a specific time period, when trigger_time is a Unix timestamp (1720061167) The WHERE clause can be written directly as WHERE trigger_time >= 1720060214 AND trigger_time < 1720061214 Or trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo(), where $__unixEpochFrom() represents the starting Unix timestamp, and $__unixEpochTo() represents the ending Unix timestamp

\`\`\`sql
SELECT COUNT(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event  
WHERE trigger_time >= $__unixEpochFrom() AND trigger_time < $__unixEpochTo()
GROUP BY time 
ORDER BY time DESC
\`\`\`

> 2.3 Query data for a specific time period, when trigger_time is in the string format "2024-07-04 10:48:01" The WHERE clause can be written directly as WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"

\`\`\`sql
SELECT COUNT(*) AS count, trigger_time AS time 
FROM n9e_v6_plus.alert_his_event  
WHERE trigger_time >= "2024-07-04 09:48:01" AND trigger_time < "2024-07-04 11:48:01"
GROUP BY time 
ORDER BY time DESC
\`\`\`

> 2.4 Query the number of alerts generated every minute for the last 7 days

\`\`\`sql
SELECT FROM_UNIXTIME(trigger_time, '%Y-%m-%d %H:%i:00') AS alert_minute, COUNT(*) AS alert_count 
FROM n9e_v6_plus.alert_his_event 
WHERE trigger_time >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY)) 
GROUP BY alert_minute 
ORDER BY alert_minute DESC;
\`\`\`

> 2.5 Sample table structure for alert_his_event

\`\`\`sql
CREATE TABLE \`alert_his_event\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
    \`cate\` varchar(128) NOT NULL,
    \`rule_id\` bigint unsigned NOT NULL,
    \`rule_name\` varchar(255) NOT NULL,
    \`prom_ql\` varchar(8192) NOT NULL COMMENT 'promql',
    \`first_trigger_time\` bigint,
    \`trigger_time\` bigint NOT NULL,
    \`trigger_value\` varchar(255) NOT NULL,
    PRIMARY KEY (\`id\`),
    KEY (\`trigger_time\`, \`rule_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
\`\`\`

### Using Macro Variables

When configuring dashboards, we usually need to query data for a time range that is not fixed but changes with the time range in the upper right corner of the dashboard. This is where time-related macro variables come in handy. Below are the macro variables we currently support and instructions for their use.

(Note: In the following explanations, 1494410783 is the start_time passed by the frontend, and 1494410983 is the end_time passed by the frontend)

\`\`\`
Macro VariableDescription
$__timeFilter(dateColumn)If dateColumn is in the format %Y-%m-%d %H:%i:%s, you can use this macro variable. It will be replaced with dateColumn BETWEEN FROM_UNIXTIME(1494410783) AND FROM_UNIXTIME(1494410983)
$__timeFrom()If the time column is in the format %Y-%m-%d %H:%i:%s, you can use this macro variable. It will be replaced with the start time of the current time selection. FROM_UNIXTIME(1494410783)
$__timeTo()If the time column is in the format %Y-%m-%d %H:%i:%s, you can use this macro variable. It will be replaced with the end time of the current time selection. FROM_UNIXTIME(1494410983)
$__unixEpochFilter(dateColumn)If dateColumn is in Unix timestamp format. It will be replaced with dateColumn > 1494410783 AND dateColumn < 1494497183
$__unixEpochFrom()Will be replaced with the start time of the current active time selection, represented as a Unix timestamp. For example, 1494410783
$__unixEpochTo()Will be replaced with the end time of the current active time selection, represented as a Unix timestamp. For example, 1494497183
$__unixEpochNanoFilter(dateColumn)If dateColumn is in nanosecond timestamp format. It will be replaced with dateColumn > 1494410783152415214 AND dateColumn < 1494410983142514872
$__unixEpochNanoFrom()Will be replaced with the start time of the current active time selection, represented as a nanosecond timestamp. For example, 1494410783152415214
$__unixEpochNanoTo()Will be replaced with the end time of the current active time selection, represented as a nanosecond timestamp. For example, 1494410983142514872
$__timeGroup(dateColumn,'5m')Used in GROUP BY, calculates data with a grouping granularity of 5 minutes
$__unixEpochGroup(dateColumn,'5m')Used in GROUP BY, calculates data with a grouping granularity of 5 minutes
\`\`\`

#### Example of Using Macro Variables

Using the alert_his_event table above as an example, the SQL to query the number of alerts per minute within a time range is as follows:

\`\`\`sql
SELECT 
  $__unixEpochGroup(trigger_time, '1m') AS time,
  COUNT(*) AS alert_count
FROM 
  n9e_v6_plus.alert_his_event
WHERE 
  $__unixEpochFilter(trigger_time)
GROUP BY 
  time
ORDER BY 
  time
\`\`\`
`;function T(t){const{darkMode:i,visible:r,destroy:_}=t,{i18n:m}=u(),a={zh_CN:d,zh_HK:p,en_US:R}[m.language];return n.jsx(h,{width:"60%",title:E.t(`${s}:query.document`),placement:"right",onClose:_,visible:r,className:"n9e-antd-drawer",children:n.jsx("div",{className:"builtin-w-md-editor","data-color-mode":i?"dark":"light",children:n.jsx(c.Markdown,{source:a,rehypeRewrite:e=>{g.includes(["h1","h2","h3","h4","h5","h6"],e.tagName)&&(e.children=e.children.filter(o=>o.tagName!="a"))}})})})}const M=l(T);export{M as D};
