import{r as e,a_ as s}from"./vendor-624cb6f3.js";function n(r){const t=e.useRef(r);return s(t.current,r)||(t.current=r),t.current}export{n as u};
