function a(t){return t==="0"?"-2":t}function e(t){return t==="-1"?"-2":t}export{e as a,a as g};
