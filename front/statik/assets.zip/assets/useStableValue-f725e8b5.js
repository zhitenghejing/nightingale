import{r as e,a_ as s}from"./vendor-ff04f3e1.js";function n(r){const t=e.useRef(r);return s(t.current,r)||(t.current=r),t.current}export{n as u};
